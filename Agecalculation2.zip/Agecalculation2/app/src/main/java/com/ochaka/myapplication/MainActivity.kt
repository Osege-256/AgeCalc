package com.ochaka.myapplication

import android.app.DatePickerDialog
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.DatePicker
import android.widget.TextView
import androidx.annotation.RequiresApi
import java.util.*

class MainActivity : AppCompatActivity() {
    @RequiresApi(Build.VERSION_CODES.N)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val button = findViewById<Button>(R.id.button)
        button.setOnClickListener {view ->
            printAge(view)

        }
    }

    @RequiresApi(Build.VERSION_CODES.N)
    private fun printAge(view: View?) {
        var myCalender = Calendar.getInstance()
        var year = myCalender.get(Calendar.YEAR)
        var month = myCalender.get(Calendar.MONTH)
        var day = myCalender.get(Calendar.DAY_OF_MONTH)

        DatePickerDialog(this, DatePickerDialog.OnDateSetListener{
            view,year,month,day ->
            val selectedDate = "${month+1}/$year"
            var textView1 = findViewById<TextView>(R.id.textView2)
            textView1.text = selectedDate

            var dob = Calendar.getInstance()
            dob.set(year,month,day)
            var age = myCalender.get(Calendar.YEAR)- dob.get(Calendar.YEAR)
            if(myCalender.get(Calendar.DAY_OF_YEAR) < dob.get(Calendar.DAY_OF_YEAR))
            {
                age--
            }
            var textView2 = findViewById<TextView>(R.id.textView2)
            textView2.text = "You are $age year old"
        }
               ,year
        ,month
        ,day) .show()



    }
}